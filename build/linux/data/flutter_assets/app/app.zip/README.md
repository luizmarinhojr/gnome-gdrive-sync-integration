![GDrive-Sync-removebg](https://github.com/luizmarinhojr/fedora-gdrive-sync-integration/assets/100722777/870e39c0-160d-4ab0-bdc4-3c75657315bd)
<br>
<a href="https://github.com/pedromxavier/flag-badges">
    <img src="https://raw.githubusercontent.com/pedromxavier/flag-badges/main/badges/BR.svg" alt="made in <country code>">
</a>

# Synchronization to Google Drive and Fedora Gnome.

## 🛠️ Under construction
